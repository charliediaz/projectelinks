-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-11-2015 a las 16:57:29
-- Versión del servidor: 5.6.26
-- Versión de PHP: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `projectelinks`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tracking`
--

CREATE TABLE IF NOT EXISTS `tbl_tracking` (
  `id_tracking` int(11) NOT NULL,
  `origen` varchar(200) NOT NULL DEFAULT '',
  `destino` varchar(200) NOT NULL DEFAULT ''
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tbl_tracking`
--

INSERT INTO `tbl_tracking` (`id_tracking`, `origen`, `destino`) VALUES
(1, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(2, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(3, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(4, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(5, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(6, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(7, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(8, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(9, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(10, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(11, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(12, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(13, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(14, 'http://localhost/projectelinks/', '/projectelinks/spy.php'),
(15, 'http://localhost/projectelinks/', '/projectelinks/spy.php');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_tracking`
--
ALTER TABLE `tbl_tracking`
  ADD PRIMARY KEY (`id_tracking`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_tracking`
--
ALTER TABLE `tbl_tracking`
  MODIFY `id_tracking` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
